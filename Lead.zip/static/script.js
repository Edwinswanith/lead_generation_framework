document.addEventListener('DOMContentLoaded', function() {
    const socket = io();
    const agentMonitoringContainer = document.getElementById('agent-monitoring-container');
    const companiesBody = document.getElementById('enriched-companies-body');
    const dataModal = new bootstrap.Modal(document.getElementById('dataModal'));

    socket.on('connect', function() {
        console.log('Connected to server');
    });

    socket.on('logs_update', function(data) {
        updateLogs(data);
    });

    socket.on('companies_update', function(data) {
        updateCompanies(data);
    });

    socket.on('token_update', function(data) {
        updateTokens(data);
    });

    socket.on('progress_update', function(data) {
        updateProgress(data);
    });

    function updateTokens(data) {
        document.getElementById('input-tokens').textContent = data.total_input_tokens;
        document.getElementById('output-tokens').textContent = data.total_output_tokens;
        document.getElementById('total-cost').textContent = `$${data.total_cost.toFixed(2)}`;
    }

    function updateProgress(data) {
        const progressBar = document.getElementById('progress-bar');
        const progressText = document.getElementById('progress-text');
        const progressContainer = document.getElementById('progress-container');
        
        if (data.total > 0) {
            progressContainer.style.display = 'block';
            const percentage = (data.processed / data.total) * 100;
            progressBar.style.width = percentage + '%';
            progressBar.setAttribute('aria-valuenow', percentage);
            progressText.textContent = `${data.processed} / ${data.total} companies processed`;

            if (data.processed === data.total) {
                progressBar.classList.remove('progress-bar-animated');
                progressBar.classList.add('bg-success');
                progressText.textContent += " - Complete!";
                // Re-enable the button
                const startButton = document.querySelector('button[onclick="startAgent()"]');
                startButton.disabled = false;
                startButton.innerHTML = '<i class="fas fa-play-circle me-2"></i>Launch Agent';
            } else {
                progressBar.classList.add('progress-bar-animated');
                progressBar.classList.remove('bg-success');
            }
        } else {
            progressContainer.style.display = 'none';
        }
    }

    function updateLogs(data) {
        agentMonitoringContainer.innerHTML = '';
        for (const agent in data) {
            const agentContainer = document.createElement('div');
            agentContainer.className = 'agent-log-container';

            const header = document.createElement('div');
            header.className = 'agent-log-header';
            header.innerHTML = `<i class="fas fa-robot me-2"></i>Agent: ${agent}`;
            agentContainer.appendChild(header);

            const body = document.createElement('div');
            body.className = 'agent-log-body';
            
            data[agent].forEach(log => {
                const logElement = document.createElement('div');
                const levelColor = log.level === 'INFO' ? '#3498db' : 
                                 log.level === 'WARNING' ? '#f1c40f' : 
                                 log.level === 'ERROR' ? '#e74c3c' : '#2ecc71';
                logElement.innerHTML = `
                    <div>
                        <span style="color: #bdc3c7">[${log.timestamp}]</span> 
                        <span style="color: ${levelColor}">[${log.level}]</span> 
                    </div>
                    <div style="padding-left: 20px;"><strong>Task:</strong> ${log.task}</div>
                `;
                body.appendChild(logElement);
            });

            agentContainer.appendChild(body);
            agentMonitoringContainer.appendChild(agentContainer);
        }
    }

    function updateCompanies(data) {
        companiesBody.innerHTML = '';
        data.forEach(company => {
            const row = document.createElement('tr');
            row.onclick = () => showCompanyDetails(company);
            row.innerHTML = `
                <td class="fw-bold text-truncate">${company['Company Name']}</td>
                <td class="text-truncate"><a href="${company['Website']}" class="text-decoration-none" target="_blank">${company['Website']}</a></td>
                <td class="text-truncate">${company['CEO Name']}</td>
                <td class="text-truncate">${company['CEO Email']}</td>
                <td class="text-truncate">${company['Company Revenue']}</td>
                <td class="text-truncate">${company['Company Employee Count']}</td>
                <td class="text-truncate">${company['Company Founding Year']}</td>
                <td class="text-truncate">${company['Target Industries']}</td>
                <td class="text-truncate">${company['Target Company Size']}</td>
                <td class="text-truncate">${company['Target Geography']}</td>
                <td class="text-truncate">${company['Client Examples']}</td>
                <td class="text-truncate">${company['Service Focus']}</td>
                <td class="text-truncate">${company['Ranking']}</td>
                <td class="text-truncate">${company['Reasoning']}</td>
            `;
            companiesBody.appendChild(row);
        });
    }

    function showCompanyDetails(company) {
        const modalContent = document.getElementById('modalContent');
        let content = '<div class="container">';
        
        for (const [key, value] of Object.entries(company)) {
            content += `
                <div class="row mb-3">
                    <div class="col-4 fw-bold">${key}:</div>
                    <div class="col-8">${value}</div>
                </div>
                <hr class="my-3">
            `;
        }
        
        content += '</div>';
        modalContent.innerHTML = content;
        document.getElementById('dataModalLabel').textContent = company['Company Name'];
        dataModal.show();
    }

    window.startAgent = function() {
        const fileInput = document.getElementById('fileInput');
        const file = fileInput.files[0];
        const startButton = document.querySelector('button[onclick="startAgent()"]');

        if (!file) {
            alert('Please select a file to upload.');
            return;
        }

        // Disable button and show loading state
        startButton.disabled = true;
        startButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...';

        // Reset UI elements
        document.getElementById('agent-monitoring-container').innerHTML = '';
        document.getElementById('enriched-companies-body').innerHTML = '';
        document.getElementById('input-tokens').textContent = '0';
        document.getElementById('output-tokens').textContent = '0';
        document.getElementById('total-cost').textContent = '$0.00';
        updateProgress({ processed: 0, total: 0 }); // Reset progress bar

        const formData = new FormData();
        formData.append('inputFile', file);

        fetch('/generate-leads', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                console.error('Error:', data.error);
                alert('An error occurred: ' + data.error);
                // Re-enable button on error
                startButton.disabled = false;
                startButton.innerHTML = '<i class="fas fa-play-circle me-2"></i>Launch Agent';
            } else {
                console.log(data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            // Re-enable button on fetch error
            startButton.disabled = false;
            startButton.innerHTML = '<i class="fas fa-play-circle me-2"></i>Launch Agent';
        });
    }

    window.downloadEnrichedData = function() {
        fetch('/download_file')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.blob();
            })
            .then(blob => {
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'enriched_companies.csv';
                document.body.appendChild(a);
                a.click();
                window.URL.revokeObjectURL(url);
                document.body.removeChild(a);
            })
            .catch(error => {
                console.error('Error downloading file:', error);
                alert('Error downloading file. Please try again.');
            });
    }
});